/* =========================================
   NOVA ADMIN APP.JS (PHASE 5 - COMPLETE)
   ========================================= */

// استيراد إعدادات Firebase من المشروع الرئيسي
import { db, auth } from '../js/firebase.js';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, query, orderBy, where, getDoc, Timestamp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";
import { signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";

const ADMIN = {
    currentUser: null,

    init() {
        // مراقبة حالة تسجيل الدخول
        onAuthStateChanged(auth, (user) => {
            if (user) {
                this.checkAdminRole(user);
            } else {
                this.showLogin();
            }
        });
    },

    // 1. AUTHENTICATION
    async login() {
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const errorEl = document.getElementById('loginError');
        errorEl.textContent = '';

        try {
            const cred = await signInWithEmailAndPassword(auth, email, password);
            this.currentUser = cred.user;
            await this.checkAdminRole(cred.user);
        } catch (e) {
            errorEl.textContent = 'بيانات الدخول غير صحيحة.';
            console.error(e);
        }
    },

    async checkAdminRole(user) {
        // التحقق من جدول المستخدمين في Firestore
        try {
            const userDoc = await getDoc(doc(db, 'users', user.uid));
            if (!userDoc.exists() || (userDoc.data().role !== 'ADMIN' && userDoc.data().role !== 'SUPER_ADMIN')) {
                this.showAccessDenied();
                return;
            }
            // سماح بالدخول
            this.currentUser = { uid: user.uid, ...userDoc.data() };
            this.showDashboard();
            this.loadDashboardStats();
        } catch (e) {
            this.showAccessDenied();
        }
    },

    // 2. UI HELPERS
    showLogin() {
        document.getElementById('admin-login').style.display = 'flex';
        document.getElementById('admin-dashboard').style.display = 'none';
    },
    showDashboard() {
        document.getElementById('admin-login').style.display = 'none';
        document.getElementById('admin-dashboard').style.display = 'block';
        document.getElementById('adminUserDisplay').textContent = this.currentUser.name || 'مدير';
    },
    showAccessDenied() {
        alert('خطأ: ليس لديك صلاحيات المدير للدخول إلى هذه اللوحة.');
        this.logout();
    },
    logout() {
        signOut(auth);
        this.showLogin();
    },

    // 3. NAVIGATION & SIDEBAR
    navigate(pageId) {
        document.querySelectorAll('.admin-page').forEach(p => p.classList.remove('active'));
        document.getElementById(`page-${pageId}`).classList.add('active');
        document.querySelectorAll('.admin-sidebar li').forEach(li => li.classList.remove('active'));
        document.querySelector(`.admin-sidebar li[data-page="${pageId}"]`).classList.add('active');
        
        // Close mobile sidebar on link click
        document.getElementById('adminSidebar').classList.remove('open');

        // Load Page Data
        if(pageId === 'currencies') this.loadCurrencies();
        if(pageId === 'rates') this.loadRates();
    },
    toggleSidebar() {
        document.getElementById('adminSidebar').classList.toggle('open');
    },

    // 4. DASHBOARD STATS
    async loadDashboardStats() {
        try {
            const currSnap = await getDocs(collection(db, 'currencies'));
            document.getElementById('statCurrencies').textContent = currSnap.size;
            
            const userSnap = await getDocs(collection(db, 'users'));
            document.getElementById('statUsers').textContent = userSnap.size;

            const ratesSnap = await getDocs(collection(db, 'rates'));
            document.getElementById('statRates').textContent = ratesSnap.size;
        } catch(e) { console.warn("Stats load error", e); }
    },

    // 5. CURRENCY MANAGEMENT
    async loadCurrencies() {
        const tbody = document.getElementById('currencyTableBody');
        tbody.innerHTML = '<tr><td colspan="5">جاري التحميل...</td></tr>';
        try {
            const q = query(collection(db, 'currencies'), orderBy('order', 'asc'));
            const snap = await getDocs(q);
            tbody.innerHTML = '';
            snap.forEach(doc => {
                const d = doc.data();
                tbody.innerHTML += `
                    <tr>
                        <td>${d.nameAr}</td>
                        <td>${d.code}</td>
                        <td style="color:var(--success)">${d.buy || 0}</td>
                        <td style="color:var(--danger)">${d.sell || 0}</td>
                        <td>
                            <button onclick="ADMIN.deleteCurrency('${doc.id}')" style="color:var(--danger); border:none;background:none;cursor:pointer;">🗑️</button>
                        </td>
                    </tr>
                `;
            });
        } catch(e) { tbody.innerHTML = '<tr><td colspan="5">خطأ في تحميل العملات</td></tr>'; }
    },

    async deleteCurrency(id) {
        if(!confirm('هل أنت متأكد من حذف هذه العملة؟')) return;
        try {
            await deleteDoc(doc(db, 'currencies', id));
            this.loadCurrencies();
        } catch(e) { alert('فشل الحذف'); }
    },

    // 6. RATES MANAGEMENT (Updated for Manual Entry)
    async loadRates() {
        const tbody = document.getElementById('rateTableBody');
        if(!tbody) return;
        tbody.innerHTML = '<tr><td colspan="5">جاري التحميل...</td></tr>';
        try {
            const snap = await db.collection('rates').orderBy('updatedAt', 'desc').get();
            tbody.innerHTML = '';
            if(snap.empty) {
                tbody.innerHTML = '<tr><td colspan="5">لا توجد أسعار مسجلة بعد.</td></tr>';
                return;
            }
            snap.forEach(doc => {
                const d = doc.data();
                const time = d.updatedAt ? new Date(d.updatedAt.seconds*1000).toLocaleString() : 'غير معروف';
                tbody.innerHTML += `
                    <tr>
                        <td><b>${d.currencyCode}</b></td>
                        <td style="color:var(--success)">${d.buyRate || 0}</td>
                        <td style="color:var(--danger)">${d.sellRate || 0}</td>
                        <td>${d.sourceId || 'يدوي'}</td>
                        <td style="font-size: 12px; color: #666;">${time}</td>
                    </tr>
                `;
            });
        } catch(e) { tbody.innerHTML = '<tr><td colspan="5">خطأ في التحميل</td></tr>'; }
    },

    // NEW: إدخال السعر يدوياً
    async submitManualRate() {
        const currency = document.getElementById('rateCurrency').value;
        const source = document.getElementById('rateSource').value;
        const buy = parseFloat(document.getElementById('rateBuy').value);
        const sell = parseFloat(document.getElementById('rateSell').value);
        const reason = document.getElementById('rateReason').value || 'تحديث يدوي';
        const msgEl = document.getElementById('rateMessage');

        // 1. التحقق من البيانات (Validation)
        if (isNaN(buy) || isNaN(sell) || buy < 0 || sell < 0) {
            msgEl.innerHTML = '<span style="color: #FF4D5E;">⚠️ خطأ: يرجى إدخال أرقام صحيحة وموجبة.</span>';
            return;
        }
        if (buy > sell) {
            if(!confirm(`تحذير: سعر الشراء (${buy}) أكبر من سعر البيع (${sell}). هل أنت متأكد من صحة البيانات؟`)) return;
        }

        msgEl.innerHTML = '<span style="color: #147BFF;">جاري الحفظ...</span>';

        try {
            const rateData = {
                currencyCode: currency,
                buyRate: buy,
                sellRate: sell,
                midRate: (buy + sell) / 2,
                sourceId: source,
                updatedAt: admin.firestore.Timestamp.now()
            };

            // 2. الحفظ في جدول الأسعار الحالي (Rates)
            await db.collection('rates').doc(currency).set(rateData, { merge: true });

            // 3. الحفظ في جدول التاريخ (Rate History) للرسوم البيانية
            await db.collection('rateHistory').add({
                ...rateData,
                reason: reason,
                timestamp: admin.firestore.Timestamp.now()
            });

            // 4. تسجيل العملية في سجل المراجعة (Audit Logs)
            await db.collection('auditLogs').add({
                adminId: this.currentUser ? this.currentUser.uid : 'unknown',
                action: 'UPDATE_RATE',
                target: currency,
                newValue: rateData,
                reason: reason,
                timestamp: admin.firestore.Timestamp.now()
            });

            msgEl.innerHTML = `<span style="color: #18C77A;">✅ تم حفظ سعر ${currency} بنجاح في قاعدة البيانات والتاريخ!</span>`;
            
            // تحديث الجدول
            this.loadRates();
            
        } catch (e) {
            msgEl.innerHTML = `<span style="color: #FF4D5E;">❌ فشل الحفظ: ${e.message}</span>`;
        }
    },

    // 7. SETTINGS
    async saveSettings() {
        alert('تم حفظ الإعدادات التجريبية بنجاح!');
    },

    // 8. MODAL SYSTEM (For future Add/Edit)
    showModal(type) {
        const modal = document.getElementById('adminModal');
        const body = document.getElementById('modalBody');
        if(type === 'currency') {
            document.getElementById('modalTitle').textContent = 'إضافة عملة جديدة';
            body.innerHTML = `
                <input type="text" placeholder="الاسم (عربي)" class="admin-input" id="mNameAr">
                <input type="text" placeholder="الكود (مثل USD)" class="admin-input" id="mCode">
                <input type="number" placeholder="سعر الشراء" class="admin-input" id="mBuy">
                <input type="number" placeholder="سعر البيع" class="admin-input" id="mSell">
            `;
            document.getElementById('modalConfirmBtn').onclick = () => this.saveCurrency();
        }
        modal.style.display = 'flex';
    },
    closeModal() {
        document.getElementById('adminModal').style.display = 'none';
    },
    async saveCurrency() {
        const data = {
            nameAr: document.getElementById('mNameAr').value,
            code: document.getElementById('mCode').value,
            buy: Number(document.getElementById('mBuy').value),
            sell: Number(document.getElementById('mSell').value),
            order: 0, createdAt: Timestamp.now()
        };
        try {
            await addDoc(collection(db, 'currencies'), data);
            this.closeModal();
            this.loadCurrencies();
        } catch(e) { alert('خطأ في الحفظ'); }
    }
};

// تشغيل التطبيق عند التحميل
document.addEventListener('DOMContentLoaded', () => ADMIN.init());

// جعل ADMIN متاحاً عالمياً للأزرار في HTML
window.ADMIN = ADMIN;