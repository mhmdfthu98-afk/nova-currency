/* =========================================
   USER SERVICE (Favorites, Alerts, Notifications)
   ========================================= */
import { db } from '../firebase.js';
import { collection, doc, getDoc, setDoc, updateDoc, arrayUnion, arrayRemove, addDoc, query, where, getDocs, Timestamp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

// إضافة/إزالة مفضلة لمستخدم مسجل
export async function toggleFavorite(userId, currencyCode) {
    const userRef = doc(db, "users", userId);
    const snap = await getDoc(userRef);
    if (!snap.exists()) return false;

    const favs = snap.data().favorites || [];
    const isFav = favs.includes(currencyCode);
    
    await updateDoc(userRef, {
        favorites: isFav ? arrayRemove(currencyCode) : arrayUnion(currencyCode)
    });
    return !isFav; // إرجاع الحالة الجديدة (مفعلة أم لا)
}

// إنشاء تنبيه
export async function createAlert(userId, currencyCode, type, condition, target) {
    await addDoc(collection(db, "alerts"), {
        userId,
        currencyCode,
        type,
        condition,
        target: Number(target),
        enabled: true,
        createdAt: Timestamp.now(),
        triggeredAt: null
    });
}

// جلب إشعارات المستخدم
export async function getUserNotifications(userId) {
    const q = query(collection(db, "notifications"), where("userId", "==", userId), orderBy("createdAt", "desc"));
    const snap = await getDocs(q);
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
}