/* =========================================
   CURRENCY & RATE SERVICE
   ========================================= */
import { db } from '../firebase.js';
import { collection, getDocs, query, orderBy, doc, getDoc, addDoc, setDoc, Timestamp } from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

// جلب قائمة العملات
export async function getCurrencies() {
    try {
        const colRef = collection(db, "currencies");
        const q = query(colRef, orderBy("order", "asc"));
        const snap = await getDocs(q);
        return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (e) {
        console.warn("Error fetching currencies:", e);
        return null;
    }
}

// جلب آخر الأسعار (آخر تحديث لكل عملة)
export async function getLatestRates() {
    try {
        const colRef = collection(db, "rates");
        // ملاحظة: هذا جلب بسيط، سنقوم بتحسينه لاحقاً للجلب الفعال
        const snap = await getDocs(colRef);
        return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    } catch (e) {
        console.warn("Error fetching rates:", e);
        return null;
    }
}

// إدخال سعر جديد (للإدارة اليدوية لاحقاً)
export async function addManualRate(currencyCode, buy, sell, mid, sourceId, reason, adminId) {
    try {
        const newRate = {
            currencyCode,
            buyRate: Number(buy),
            sellRate: Number(sell),
            midRate: Number(mid),
            sourceId,
            sourceType: 'MANUAL',
            updatedAt: Timestamp.now(),
            createdAt: Timestamp.now(),
            status: 'active'
        };
        await addDoc(collection(db, "rates"), newRate);
        return true;
    } catch (e) {
        console.error("Error adding manual rate:", e);
        return false;
    }
}